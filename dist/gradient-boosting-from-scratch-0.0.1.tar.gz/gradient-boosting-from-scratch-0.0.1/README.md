# Python Gradient Boosting from scratch
This is an implementation of the gradient boosting algorithm from zero. The coding philosophy focuses on facilitating the understanding of the algorithm rather than on providing optimal efficiency.
The proposed estructure is modular so that you can replace some parts by custom ones and try out your ideas.



